<?php
  $links = array(
    'css' => 'lib/ionicons/css/ionicons.min.css'
  );
?>
